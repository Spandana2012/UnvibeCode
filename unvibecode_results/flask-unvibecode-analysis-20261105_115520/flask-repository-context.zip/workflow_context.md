# flask — Context for AI

6 workflows · 0 risk findings · 403 verified connections · 482 code sections

Attach this file and `chunks.jsonl` together. Every code reference below identifies a source section in `chunks.jsonl`.

## 1. Business workflows

### 1. Create JSON-formatted HTTP responses

Workflow ID: `business_path_ba67ffff521156cd`

A caller of Flask's jsonify helper supplies values; the active application's JSON provider serializes them into an HTTP response object with JSON media type.

**Purpose:** Return structured data to an HTTP client

**Business outcome**

- Provides a standardized JSON representation and response media type

**Important behavior and rules**

- JSON response preparation rejects simultaneous positional and keyword arguments.
- With no supplied arguments, the response object to serialize is None.
- A JSON provider response is constructed using the configured application response class and application/json mimetype.
- An active application context is required to call jsonify.

**Identified functions:** `flask.json.jsonify(*args, **kwargs)`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| JSONProvider.response | `src/flask/json/provider.py` | `chunk_6c67156ce7d4bcad` |
| jsonify | `src/flask/json/__init__.py` | `chunk_bbf28cdf796b929b` |

### 2. Request dispatch and response finalization

Workflow ID: `business_path_fdd49be633d69295`

A WSGI server supplies a request to the Flask application; Flask runs request preprocessing, dispatches to a matching view or automatic OPTIONS response, finalizes the result, and returns the WSGI response.

**Purpose:** Obtain the response produced by the application for an HTTP request.

**Business outcome**

- Routes a request to application behavior and produces a WSGI response.

**Important behavior and rules**

- Dispatch calls the registered view for the matched endpoint unless the request is handled by automatic OPTIONS behavior or preprocessing supplies a result.
- A view result of None is invalid; supported response values are converted to the configured response class.
- If a before-request function returns a non-None value, that value is used as the request result and further request handling stops.
- A view result of None is rejected as an invalid response.

**Identified functions:** `Flask.__call__`, `Flask.wsgi_app`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| Source section | `src/flask/app.py` | `chunk_202df8247807557d` |
| Source section | `src/flask/app.py` | `chunk_208869a6ca0eb4ba` |
| Source section | `src/flask/app.py` | `chunk_4d856dffb2d1c0a3` |
| Source section | `src/flask/app.py` | `chunk_4de3e54cea769505` |
| Source section | `src/flask/app.py` | `chunk_8c4aa59e3a8b40bb` |
| Source section | `src/flask/app.py` | `chunk_a89de0d1a878d7fa` |
| Source section | `src/flask/app.py` | `chunk_ae04b44954f880ec` |

### 3. Run a local development server for a Flask application.

Workflow ID: `business_path_c6605356c86909f5`

A Flask CLI user invokes run_command; Flask loads the configured application and starts the Werkzeug development server.

**Purpose:** Start the selected Flask application for development.

**Business outcome**

- Makes the loaded application available through the configured host and port.
- The code documents the server as development-only, not a production WSGI server.

**Important behavior and rules**

- When reload or debugger is unspecified, its value defaults to the debug setting.
- The run command is documented as a development server rather than a production WSGI server.
- If loading the application raises while running under the reloader, the exception is printed and an application callable that raises the error is passed onward; otherwise the exception is raised immediately.

**Identified functions:** `flask run command (run_command)`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| cli module imports | `src/flask/cli.py` | `chunk_03327f5e7eb41467` |
| run_command | `src/flask/cli.py` | `chunk_979f1ff9f1897a64` |

### 4. Attach deferred Blueprint routes, callbacks, and commands to a Flask application.

Workflow ID: `business_path_1d3f024280de8981`

Application registration of a Blueprint records it in the application's registry, merges applicable callbacks, applies deferred setup functions, and registers nested blueprints and CLI commands.

**Purpose:** Make a configured Blueprint's application features available on an application.

**Business outcome**

- Makes blueprint-defined routes and callbacks part of the application.
- Supports nested blueprints and configurable route prefixes, subdomains, and names.

**Important behavior and rules**

- A Blueprint registration name must be unique in the application's blueprint registry.
- A Blueprint cannot be registered as a nested child of itself.
- Deferred callback execution and some registry merges are conditioned on first registration or first use of the registration name.
- A registration name already present in app.blueprints causes ValueError.
- A Blueprint cannot register itself as a nested Blueprint.
- Blueprint setup methods reject further setup after the Blueprint has been registered once.

**Identified functions:** `Blueprint.register(app, options)`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| Source section | `src/flask/sansio/blueprints.py` | `chunk_8983f7abe21577fa` |
| Source section | `src/flask/sansio/blueprints.py` | `chunk_d9af4d179c6a6578` |
| Source section | `src/flask/sansio/blueprints.py` | `chunk_f99f85f5f5bd3d1c` |

### 5. Serve a Blueprint's static file to a requesting client.

Workflow ID: `business_path_8e12ca4842c24b37`

A request reaching a registered Blueprint static route invokes send_static_file, which serves a file from the Blueprint static folder through send_from_directory.

**Purpose:** Retrieve a static file exposed by the application.

**Business outcome**

- Returns requested file contents when available.
- The directory-based helper confines requested paths to the configured directory and reports missing or non-regular targets as 404 according to its documented contract.

**Important behavior and rules**

- Blueprint static serving requires a configured static folder.
- send_from_directory is documented to keep the requested path under the supplied directory and return 404 when the target is not an existing regular file.
- If the Blueprint has no static folder, send_static_file raises RuntimeError.
- The helper is documented to constrain the requested path to the configured directory and to raise 404 when the final path is not an existing regular file.

**Identified functions:** `Blueprint.send_static_file (registered as a static view when static_folder is configured)`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| send_from_directory | `src/flask/helpers.py` | `chunk_14eaa200de800fcc` |
| Blueprint.send_static_file | `src/flask/blueprints.py` | `chunk_2a11840d2c2debd8` |

### 6. Save a request session using a signed cookie.

Workflow ID: `business_path_a1eba882498c7f3a`

At the end of a request, Flask's default SecureCookieSessionInterface evaluates the session and may set or delete its signed session cookie on the response.

**Purpose:** Preserve session data across requests.

**Business outcome**

- Allows session data to be carried in a signed cookie when the interface has a signing key.
- Signals cookie variation to intermediaries when session data was accessed or the cookie changes.

**Important behavior and rules**

- A session cookie is set when the session is modified, or when it is permanent and SESSION_REFRESH_EACH_REQUEST is enabled, subject to the session being non-empty.
- A modified session that is empty causes the session cookie to be deleted; an empty unmodified session returns without setting the cookie.
- The default signed-cookie session interface requires a configured secret key to create a signing serializer; if open_session returns None, the request context uses a null session.
- The session cookie is signed using the current secret key, with configured SECRET_KEY_FALLBACKS included in the serializer key list.
- A cookie is set only if the session is non-empty and should_set_cookie returns true; that predicate is true for modified sessions or permanent sessions when SESSION_REFRESH_EACH_REQUEST is enabled.
- If the session is empty but modified, its cookie is deleted; if empty and unmodified, save_session returns without setting a cookie.
- No signing serializer is created when app.secret_key is falsey.

**Identified functions:** `SessionInterface.save_session (called at the end of a request, per its docstring)`

**Implementation references**

| Function or code area | File | Chunk ID |
|---|---|---|
| SessionInterface.save_session | `src/flask/sessions.py` | `chunk_277df63995874727` |
| SecureCookieSessionInterface.save_session | `src/flask/sessions.py` | `chunk_3c8a6bfae0776ce3` |
| Source section | `src/flask/ctx.py` | `chunk_a6940afbd6f42ea7` |
| SessionMixin.permanent | `src/flask/sessions.py` | `chunk_c6bd3a958ae29ccf` |
| SecureCookieSession.__init__ | `src/flask/sessions.py` | `chunk_ea6fb811df40af69` |

## 2. Verified code connections and remaining repository context

Connections are static source relationships; they do not prove runtime execution.

- `chunk_03327f5e7eb41467` → `chunk_08d67f9ea2f8c3bf`: file_import; symbol: not specified
- `chunk_03327f5e7eb41467` → `chunk_0974fadcf02fc3bc`: imports_symbol; symbol: get_load_dotenv
- `chunk_03327f5e7eb41467` → `chunk_500c67581ba1971f`: imports_symbol; symbol: get_debug_flag
- `chunk_03327f5e7eb41467` → `chunk_8cce5ef592c7abc6`: file_import; symbol: not specified
- `chunk_03327f5e7eb41467` → `chunk_d89edffad1fc2099`: imports_module; symbol: not specified
- `chunk_03327f5e7eb41467` → `chunk_d89edffad1fc2099`: file_import; symbol: not specified
- `chunk_03327f5e7eb41467` → `chunk_ed378ed504c07fca`: file_import; symbol: not specified
- `chunk_03327f5e7eb41467` → `chunk_fc344ad5edc4b52f`: file_import; symbol: not specified
- `chunk_05e5b226d8a8f906` → `chunk_08d67f9ea2f8c3bf`: file_import; symbol: not specified
- `chunk_05e5b226d8a8f906` → `chunk_2a11840d2c2debd8`: imports_symbol; symbol: Blueprint
- `chunk_05e5b226d8a8f906` → `chunk_2a11840d2c2debd8`: file_import; symbol: not specified
- `chunk_05e5b226d8a8f906` → `chunk_a793714a798140b5`: file_import; symbol: not specified
- `chunk_05e5b226d8a8f906` → `chunk_d32aebe41ab61974`: file_import; symbol: not specified
- `chunk_05e5b226d8a8f906` → `chunk_d89edffad1fc2099`: imports_module; symbol: not specified
- `chunk_05e5b226d8a8f906` → `chunk_d89edffad1fc2099`: file_import; symbol: not specified
- `chunk_05e5b226d8a8f906` → `chunk_dd100daace83e5ce`: imports_symbol; symbol: App
- `chunk_05e5b226d8a8f906` → `chunk_e65b72105426b434`: file_import; symbol: not specified
- `chunk_079d522beff21bdb` → `chunk_d32aebe41ab61974`: file_import; symbol: not specified
- `chunk_079d522beff21bdb` → `chunk_d89edffad1fc2099`: imports_module; symbol: not specified
- `chunk_079d522beff21bdb` → `chunk_d89edffad1fc2099`: file_import; symbol: not specified
- `chunk_07bb9517c541cdb7` → `chunk_2c910577b76376cf`: imports_symbol; symbol: render_template
- `chunk_07bb9517c541cdb7` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_08d67f9ea2f8c3bf` → `chunk_08e16ed6f5967458`: file_import; symbol: not specified
- `chunk_08d67f9ea2f8c3bf` → `chunk_a793714a798140b5`: file_import; symbol: not specified
- `chunk_08d67f9ea2f8c3bf` → `chunk_d2edbd1432944397`: file_import; symbol: not specified
- `chunk_08d67f9ea2f8c3bf` → `chunk_d89edffad1fc2099`: imports_module; symbol: not specified
- `chunk_08d67f9ea2f8c3bf` → `chunk_d89edffad1fc2099`: file_import; symbol: not specified
- `chunk_08d67f9ea2f8c3bf` → `chunk_fc344ad5edc4b52f`: file_import; symbol: not specified
- `chunk_08e16ed6f5967458` → `chunk_39a4d795b4a8111a`: file_import; symbol: not specified
- `chunk_08e16ed6f5967458` → `chunk_a793714a798140b5`: file_import; symbol: not specified
- `chunk_08e16ed6f5967458` → `chunk_d89edffad1fc2099`: imports_module; symbol: not specified
- `chunk_08e16ed6f5967458` → `chunk_d89edffad1fc2099`: file_import; symbol: not specified
- `chunk_08e16ed6f5967458` → `chunk_e381cc4175c1d4ac`: imports_symbol; symbol: TaggedJSONSerializer
- `chunk_08e16ed6f5967458` → `chunk_fc344ad5edc4b52f`: file_import; symbol: not specified
- `chunk_092982a8e67b4df9` → `chunk_091ff3fea5244e71`: imports_symbol; symbol: FlaskClient
- `chunk_092982a8e67b4df9` → `chunk_ae6ad21b2fc0258f`: file_import; symbol: not specified
- `chunk_0b1a7e8eac1bdf86` → `chunk_6c67156ce7d4bcad`: imports_symbol; symbol: DefaultJSONProvider
- `chunk_0b1a7e8eac1bdf86` → `chunk_6c67156ce7d4bcad`: file_import; symbol: not specified
- `chunk_0b1a7e8eac1bdf86` → `chunk_6f518c88b8a0e44d`: imports_module; symbol: not specified
- `chunk_0b1a7e8eac1bdf86` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_0dcaca236c8dd90b` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_0dcaca236c8dd90b` → `chunk_e1d5287efc4fa5ef`: imports_symbol; symbol: Flask
- `chunk_0ea771d2dc963ea7` → `chunk_08d67f9ea2f8c3bf`: file_import; symbol: not specified
- `chunk_0ea771d2dc963ea7` → `chunk_091ff3fea5244e71`: imports_symbol; symbol: FlaskClient
- `chunk_0ea771d2dc963ea7` → `chunk_6f518c88b8a0e44d`: imports_module; symbol: not specified
- `chunk_0ea771d2dc963ea7` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_0ea771d2dc963ea7` → `chunk_ae6ad21b2fc0258f`: file_import; symbol: not specified
- `chunk_0ea771d2dc963ea7` → `chunk_cd26e931d51d690c`: imports_symbol; symbol: app_ctx
- `chunk_0ea771d2dc963ea7` → `chunk_d89edffad1fc2099`: imports_module; symbol: not specified
- `chunk_0ea771d2dc963ea7` → `chunk_d89edffad1fc2099`: file_import; symbol: not specified
- `chunk_13b1a0f012773de6` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_13b1a0f012773de6` → `chunk_e1d5287efc4fa5ef`: imports_symbol; symbol: Flask
- `chunk_1cc6e0ef42852fa7` → `chunk_0bf0bfdb68912f6c`: imports_symbol; symbol: JSONTag
- `chunk_1cc6e0ef42852fa7` → `chunk_39a4d795b4a8111a`: file_import; symbol: not specified
- `chunk_1cc6e0ef42852fa7` → `chunk_e381cc4175c1d4ac`: imports_symbol; symbol: TaggedJSONSerializer
- `chunk_23539d2eaa639921` → `chunk_ae6ad21b2fc0258f`: file_import; symbol: not specified
- `chunk_246c820854be1b6a` → `chunk_03327f5e7eb41467`: file_import; symbol: not specified
- `chunk_2a11840d2c2debd8` → `chunk_03327f5e7eb41467`: file_import; symbol: not specified
- `chunk_2a11840d2c2debd8` → `chunk_08d67f9ea2f8c3bf`: file_import; symbol: not specified
- `chunk_2a11840d2c2debd8` → `chunk_14eaa200de800fcc`: imports_symbol; symbol: send_from_directory
- `chunk_2a11840d2c2debd8` → `chunk_3b20a473c486db47`: imports_symbol; symbol: BlueprintSetupState
- `chunk_2a11840d2c2debd8` → `chunk_487841d24a31fccb`: file_import; symbol: not specified
- `chunk_2a11840d2c2debd8` → `chunk_6088cc242bf9ab3f`: imports_symbol; symbol: AppGroup
- `chunk_2a11840d2c2debd8` → `chunk_8cce5ef592c7abc6`: file_import; symbol: not specified
- `chunk_2a11840d2c2debd8` → `chunk_a793714a798140b5`: file_import; symbol: not specified
- `chunk_2a11840d2c2debd8` → `chunk_d89edffad1fc2099`: imports_module; symbol: not specified
- `chunk_2a11840d2c2debd8` → `chunk_d89edffad1fc2099`: file_import; symbol: not specified
- `chunk_2a11840d2c2debd8` → `chunk_d9af4d179c6a6578`: imports_symbol; symbol: Blueprint
- `chunk_2a11840d2c2debd8` → `chunk_e65b72105426b434`: file_import; symbol: not specified
- `chunk_2c1084f7c7016b47` → `chunk_06d0425a273b91e9`: imports_symbol; symbol: after_this_request
- `chunk_2c1084f7c7016b47` → `chunk_079d522beff21bdb`: file_import; symbol: not specified
- `chunk_2c1084f7c7016b47` → `chunk_08d67f9ea2f8c3bf`: file_import; symbol: not specified
- `chunk_2c1084f7c7016b47` → `chunk_0c32d6cc911ef525`: imports_symbol; symbol: flash
- `chunk_2c1084f7c7016b47` → `chunk_14eaa200de800fcc`: imports_symbol; symbol: send_from_directory
- `chunk_2c1084f7c7016b47` → `chunk_29ffcfc402bbb372`: imports_symbol; symbol: send_file
- `chunk_2c1084f7c7016b47` → `chunk_2a11840d2c2debd8`: imports_symbol; symbol: Blueprint
- `chunk_2c1084f7c7016b47` → `chunk_2a11840d2c2debd8`: file_import; symbol: not specified
- `chunk_2c1084f7c7016b47` → `chunk_2c910577b76376cf`: imports_symbol; symbol: render_template
- `chunk_2c1084f7c7016b47` → `chunk_2c910577b76376cf`: imports_symbol; symbol: render_template_string
- `chunk_2c1084f7c7016b47` → `chunk_2c910577b76376cf`: imports_symbol; symbol: stream_template
- `chunk_2c1084f7c7016b47` → `chunk_2c910577b76376cf`: imports_symbol; symbol: stream_template_string
- `chunk_2c1084f7c7016b47` → `chunk_2c910577b76376cf`: file_import; symbol: not specified
- `chunk_2c1084f7c7016b47` → `chunk_34d76a0b6682f882`: imports_symbol; symbol: has_app_context
- `chunk_2c1084f7c7016b47` → `chunk_3575a2cecb320120`: imports_symbol; symbol: abort
- `chunk_2c1084f7c7016b47` → `chunk_36957f18a0a76b79`: imports_symbol; symbol: get_flashed_messages
- `chunk_2c1084f7c7016b47` → `chunk_5d5cf31f2ee2c92c`: imports_symbol; symbol: url_for
- `chunk_2c1084f7c7016b47` → `chunk_6480eead4a4aa1ab`: imports_symbol; symbol: get_template_attribute
- `chunk_2c1084f7c7016b47` → `chunk_767441e328879929`: imports_symbol; symbol: stream_with_context
- `chunk_2c1084f7c7016b47` → `chunk_7e5fa90f1cd8ceed`: imports_symbol; symbol: Request
- `chunk_2c1084f7c7016b47` → `chunk_7f9d033f78e38483`: file_import; symbol: not specified
- `chunk_2c1084f7c7016b47` → `chunk_8cce5ef592c7abc6`: file_import; symbol: not specified
- `chunk_2c1084f7c7016b47` → `chunk_9cbcb5b6daffc5e3`: imports_symbol; symbol: copy_current_request_context
- `chunk_2c1084f7c7016b47` → `chunk_a793714a798140b5`: file_import; symbol: not specified
- `chunk_2c1084f7c7016b47` → `chunk_bbf28cdf796b929b`: imports_symbol; symbol: jsonify
- `chunk_2c1084f7c7016b47` → `chunk_bbf28cdf796b929b`: file_import; symbol: not specified
- `chunk_2c1084f7c7016b47` → `chunk_cd1ac4ab4dfc74dc`: imports_symbol; symbol: Config
- `chunk_2c1084f7c7016b47` → `chunk_d0db06956f7ea0fe`: imports_symbol; symbol: has_request_context
- `chunk_2c1084f7c7016b47` → `chunk_d2edbd1432944397`: file_import; symbol: not specified
- `chunk_2c1084f7c7016b47` → `chunk_e1d5287efc4fa5ef`: imports_symbol; symbol: Flask
- `chunk_2c1084f7c7016b47` → `chunk_e67d0957cb67fc02`: imports_symbol; symbol: Response
- `chunk_2c1084f7c7016b47` → `chunk_ead2aba9c8e43912`: imports_symbol; symbol: make_response
- `chunk_2c1084f7c7016b47` → `chunk_fc344ad5edc4b52f`: file_import; symbol: not specified
- `chunk_2c1084f7c7016b47` → `chunk_fc92c568a3e5fcab`: imports_symbol; symbol: redirect
- `chunk_2c910577b76376cf` → `chunk_05e5b226d8a8f906`: file_import; symbol: not specified
- `chunk_2c910577b76376cf` → `chunk_08d67f9ea2f8c3bf`: file_import; symbol: not specified
- `chunk_2c910577b76376cf` → `chunk_767441e328879929`: imports_symbol; symbol: stream_with_context
- `chunk_2c910577b76376cf` → `chunk_7f9d033f78e38483`: file_import; symbol: not specified
- `chunk_2c910577b76376cf` → `chunk_8cce5ef592c7abc6`: file_import; symbol: not specified
- `chunk_2c910577b76376cf` → `chunk_a6940afbd6f42ea7`: imports_symbol; symbol: AppContext
- `chunk_2c910577b76376cf` → `chunk_cd26e931d51d690c`: imports_symbol; symbol: app_ctx
- `chunk_2c910577b76376cf` → `chunk_d2edbd1432944397`: file_import; symbol: not specified
- `chunk_2c910577b76376cf` → `chunk_d32aebe41ab61974`: file_import; symbol: not specified
- `chunk_2c910577b76376cf` → `chunk_d89edffad1fc2099`: imports_module; symbol: not specified
- `chunk_2c910577b76376cf` → `chunk_d89edffad1fc2099`: file_import; symbol: not specified
- `chunk_2c910577b76376cf` → `chunk_e65b72105426b434`: file_import; symbol: not specified
- `chunk_2fd24549467d3ba6` → `chunk_39cf700819890adc`: file_import; symbol: not specified
- `chunk_2fd24549467d3ba6` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_2fd24549467d3ba6` → `chunk_c0eef923d4b41e30`: file_import; symbol: not specified
- `chunk_2fd24549467d3ba6` → `chunk_ccdfaa0f380ec07a`: file_import; symbol: not specified
- `chunk_2fd24549467d3ba6` → `chunk_e1d5287efc4fa5ef`: imports_symbol; symbol: Flask
- `chunk_340cdfcae1cb4b4d` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_340cdfcae1cb4b4d` → `chunk_e1d5287efc4fa5ef`: imports_symbol; symbol: Flask
- `chunk_364b2616c7c72f56` → `chunk_6f518c88b8a0e44d`: imports_module; symbol: not specified
- `chunk_364b2616c7c72f56` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_364b2616c7c72f56` → `chunk_c89a6b5182f3b837`: imports_module; symbol: not specified
- `chunk_364b2616c7c72f56` → `chunk_c89a6b5182f3b837`: file_import; symbol: not specified
- `chunk_37874a17b33c977c` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_39a4d795b4a8111a` → `chunk_bbf28cdf796b929b`: imports_symbol; symbol: dumps
- `chunk_39a4d795b4a8111a` → `chunk_bbf28cdf796b929b`: imports_symbol; symbol: loads
- `chunk_39a4d795b4a8111a` → `chunk_bbf28cdf796b929b`: file_import; symbol: not specified
- `chunk_39a4d795b4a8111a` → `chunk_d89edffad1fc2099`: imports_module; symbol: not specified
- `chunk_39a4d795b4a8111a` → `chunk_d89edffad1fc2099`: file_import; symbol: not specified
- `chunk_39cf700819890adc` → `chunk_0c32d6cc911ef525`: imports_symbol; symbol: flash
- `chunk_39cf700819890adc` → `chunk_2c910577b76376cf`: imports_symbol; symbol: render_template
- `chunk_39cf700819890adc` → `chunk_5d5cf31f2ee2c92c`: imports_symbol; symbol: url_for
- `chunk_39cf700819890adc` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_39cf700819890adc` → `chunk_c0eef923d4b41e30`: imports_symbol; symbol: login_required
- `chunk_39cf700819890adc` → `chunk_c0eef923d4b41e30`: file_import; symbol: not specified
- `chunk_39cf700819890adc` → `chunk_ccdfaa0f380ec07a`: imports_symbol; symbol: get_db
- `chunk_39cf700819890adc` → `chunk_ccdfaa0f380ec07a`: file_import; symbol: not specified
- `chunk_39cf700819890adc` → `chunk_fc92c568a3e5fcab`: imports_symbol; symbol: redirect
- `chunk_3a3a1d3005368514` → `chunk_2c910577b76376cf`: imports_symbol; symbol: render_template
- `chunk_3a3a1d3005368514` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_47e242225e1d303b` → `chunk_500c67581ba1971f`: imports_symbol; symbol: get_debug_flag
- `chunk_47e242225e1d303b` → `chunk_6f518c88b8a0e44d`: imports_module; symbol: not specified
- `chunk_47e242225e1d303b` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_47e242225e1d303b` → `chunk_8cce5ef592c7abc6`: file_import; symbol: not specified
- `chunk_487841d24a31fccb` → `chunk_0f14a6cec0376f18`: imports_symbol; symbol: _endpoint_from_view_func
- `chunk_487841d24a31fccb` → `chunk_53f0d53d1eb1f300`: imports_symbol; symbol: setupmethod
- `chunk_487841d24a31fccb` → `chunk_d32aebe41ab61974`: file_import; symbol: not specified
- `chunk_487841d24a31fccb` → `chunk_d633e0c444ff7754`: imports_symbol; symbol: Scaffold
- `chunk_487841d24a31fccb` → `chunk_d89edffad1fc2099`: imports_module; symbol: not specified
- `chunk_487841d24a31fccb` → `chunk_d89edffad1fc2099`: file_import; symbol: not specified
- `chunk_487841d24a31fccb` → `chunk_e65b72105426b434`: file_import; symbol: not specified
- `chunk_4eca314f1a9aa408` → `chunk_05e5b226d8a8f906`: file_import; symbol: not specified
- `chunk_4fbea67b4cf78839` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_4fbea67b4cf78839` → `chunk_e1d5287efc4fa5ef`: imports_symbol; symbol: Flask
- `chunk_58ecb39b8e8d9713` → `chunk_ccdfaa0f380ec07a`: imports_symbol; symbol: get_db
- `chunk_58ecb39b8e8d9713` → `chunk_ccdfaa0f380ec07a`: imports_symbol; symbol: init_db
- `chunk_58ecb39b8e8d9713` → `chunk_ccdfaa0f380ec07a`: file_import; symbol: not specified
- `chunk_612377321a46ae96` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_612377321a46ae96` → `chunk_e1d5287efc4fa5ef`: imports_symbol; symbol: Flask
- `chunk_642a47cdad401c03` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_642a47cdad401c03` → `chunk_e1d5287efc4fa5ef`: imports_symbol; symbol: Flask
- `chunk_646594ea66ce148b` → `chunk_6f518c88b8a0e44d`: imports_module; symbol: not specified
- `chunk_646594ea66ce148b` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_6c67156ce7d4bcad` → `chunk_d32aebe41ab61974`: file_import; symbol: not specified
- `chunk_6c67156ce7d4bcad` → `chunk_d89edffad1fc2099`: imports_module; symbol: not specified
- `chunk_6c67156ce7d4bcad` → `chunk_d89edffad1fc2099`: file_import; symbol: not specified
- `chunk_6f518c88b8a0e44d` → `chunk_e1d5287efc4fa5ef`: imports_symbol; symbol: Flask
- `chunk_7c4eff8cf0cd72cc` → `chunk_6f518c88b8a0e44d`: imports_module; symbol: not specified
- `chunk_7c4eff8cf0cd72cc` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_7c93120950e7c730` → `chunk_03327f5e7eb41467`: file_import; symbol: not specified
- `chunk_7e5fa90f1cd8ceed` → `chunk_05e5b226d8a8f906`: file_import; symbol: not specified
- `chunk_7eea0803ec01a0ea` → `chunk_03327f5e7eb41467`: file_import; symbol: not specified
- `chunk_7eea0803ec01a0ea` → `chunk_1d759850fa45fce3`: imports_symbol; symbol: get_version
- `chunk_7eea0803ec01a0ea` → `chunk_222b449204f0f059`: imports_symbol; symbol: prepare_import
- `chunk_7eea0803ec01a0ea` → `chunk_5d949a360d45c2ce`: imports_symbol; symbol: ScriptInfo
- `chunk_7eea0803ec01a0ea` → `chunk_6088cc242bf9ab3f`: imports_symbol; symbol: AppGroup
- `chunk_7eea0803ec01a0ea` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_7eea0803ec01a0ea` → `chunk_979f1ff9f1897a64`: imports_symbol; symbol: run_command
- `chunk_7eea0803ec01a0ea` → `chunk_ae6ad21b2fc0258f`: file_import; symbol: not specified
- `chunk_7eea0803ec01a0ea` → `chunk_b75110488e13ee01`: imports_symbol; symbol: load_dotenv
- `chunk_7eea0803ec01a0ea` → `chunk_b7b0f2b916869b76`: imports_symbol; symbol: FlaskGroup
- `chunk_7eea0803ec01a0ea` → `chunk_c342b07709d3ac6b`: imports_symbol; symbol: with_appcontext
- `chunk_7eea0803ec01a0ea` → `chunk_d97015c105003a3f`: imports_symbol; symbol: find_best_app
- `chunk_7eea0803ec01a0ea` → `chunk_dcab47d8a041180b`: imports_symbol; symbol: locate_app
- `chunk_7eea0803ec01a0ea` → `chunk_e1d5287efc4fa5ef`: imports_symbol; symbol: Flask
- `chunk_7eea0803ec01a0ea` → `chunk_ed3186b5dce1ee2f`: imports_symbol; symbol: NoAppException
- `chunk_8b04179a9854c150` → `chunk_42fa185a7e4af7e2`: file_import; symbol: not specified
- `chunk_8b04179a9854c150` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_8cce5ef592c7abc6` → `chunk_08d67f9ea2f8c3bf`: file_import; symbol: not specified
- `chunk_8cce5ef592c7abc6` → `chunk_7f9d033f78e38483`: file_import; symbol: not specified
- `chunk_8cce5ef592c7abc6` → `chunk_a793714a798140b5`: file_import; symbol: not specified
- `chunk_8cce5ef592c7abc6` → `chunk_cd26e931d51d690c`: imports_symbol; symbol: app_ctx
- `chunk_8cce5ef592c7abc6` → `chunk_d89edffad1fc2099`: imports_module; symbol: not specified
- `chunk_8cce5ef592c7abc6` → `chunk_d89edffad1fc2099`: file_import; symbol: not specified
- `chunk_8cce5ef592c7abc6` → `chunk_e67d0957cb67fc02`: imports_symbol; symbol: Response
- `chunk_8eb1e0b497ed12a1` → `chunk_6f518c88b8a0e44d`: imports_module; symbol: not specified
- `chunk_8eb1e0b497ed12a1` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_93794da8f1487f6e` → `chunk_6f518c88b8a0e44d`: imports_module; symbol: not specified
- `chunk_93794da8f1487f6e` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_9d6ac0ddce7faa56` → `chunk_c89a6b5182f3b837`: imports_module; symbol: not specified
- `chunk_9d6ac0ddce7faa56` → `chunk_c89a6b5182f3b837`: imports_symbol; symbol: has_level_handler
- `chunk_9d6ac0ddce7faa56` → `chunk_c89a6b5182f3b837`: imports_symbol; symbol: wsgi_errors_stream
- `chunk_9d6ac0ddce7faa56` → `chunk_c89a6b5182f3b837`: file_import; symbol: not specified
- `chunk_a793714a798140b5` → `chunk_08d67f9ea2f8c3bf`: file_import; symbol: not specified
- `chunk_a793714a798140b5` → `chunk_5204c53d5d715ef6`: imports_symbol; symbol: _split_blueprint_path
- `chunk_a793714a798140b5` → `chunk_8cce5ef592c7abc6`: file_import; symbol: not specified
- `chunk_a793714a798140b5` → `chunk_bbf28cdf796b929b`: file_import; symbol: not specified
- `chunk_a793714a798140b5` → `chunk_d89edffad1fc2099`: imports_module; symbol: not specified
- `chunk_a793714a798140b5` → `chunk_d89edffad1fc2099`: file_import; symbol: not specified
- `chunk_ac530dd929c76a21` → `chunk_ccdfaa0f380ec07a`: imports_symbol; symbol: get_db
- `chunk_ac530dd929c76a21` → `chunk_ccdfaa0f380ec07a`: file_import; symbol: not specified
- `chunk_ad7e71b59e357b17` → `chunk_03327f5e7eb41467`: file_import; symbol: not specified
- `chunk_ad7e71b59e357b17` → `chunk_afda8edb08f57c20`: imports_symbol; symbol: main
- `chunk_ae04b44954f880ec` → `chunk_ae6ad21b2fc0258f`: file_import; symbol: not specified
- `chunk_ae6ad21b2fc0258f` → `chunk_03327f5e7eb41467`: file_import; symbol: not specified
- `chunk_ae6ad21b2fc0258f` → `chunk_08e16ed6f5967458`: file_import; symbol: not specified
- `chunk_ae6ad21b2fc0258f` → `chunk_5d949a360d45c2ce`: imports_symbol; symbol: ScriptInfo
- `chunk_ae6ad21b2fc0258f` → `chunk_7e5fa90f1cd8ceed`: imports_symbol; symbol: Request
- `chunk_ae6ad21b2fc0258f` → `chunk_8cb0fead4a2cd549`: imports_module; symbol: not specified
- `chunk_ae6ad21b2fc0258f` → `chunk_8cb0fead4a2cd549`: file_import; symbol: not specified
- `chunk_ae6ad21b2fc0258f` → `chunk_a793714a798140b5`: file_import; symbol: not specified
- `chunk_ae6ad21b2fc0258f` → `chunk_c6bd3a958ae29ccf`: imports_symbol; symbol: SessionMixin
- `chunk_ae6ad21b2fc0258f` → `chunk_d89edffad1fc2099`: imports_module; symbol: not specified
- `chunk_ae6ad21b2fc0258f` → `chunk_d89edffad1fc2099`: file_import; symbol: not specified
- `chunk_ae6ad21b2fc0258f` → `chunk_ed378ed504c07fca`: file_import; symbol: not specified
- `chunk_ae6ad21b2fc0258f` → `chunk_fc344ad5edc4b52f`: file_import; symbol: not specified
- `chunk_aeaff9ba5c83618b` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_aeaff9ba5c83618b` → `chunk_e1d5287efc4fa5ef`: imports_symbol; symbol: Flask
- `chunk_b304ef07c4bd2603` → `chunk_ccdfaa0f380ec07a`: imports_symbol; symbol: get_db
- `chunk_b304ef07c4bd2603` → `chunk_ccdfaa0f380ec07a`: file_import; symbol: not specified
- `chunk_b4748b8723c16f0b` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_b4748b8723c16f0b` → `chunk_e1d5287efc4fa5ef`: imports_symbol; symbol: Flask
- `chunk_b4748b8723c16f0b` → `chunk_ec18eff741183616`: imports_symbol; symbol: MethodView
- `chunk_b4748b8723c16f0b` → `chunk_ec18eff741183616`: imports_symbol; symbol: View
- `chunk_b6fd669f73039529` → `chunk_5d5cf31f2ee2c92c`: imports_symbol; symbol: url_for
- `chunk_b6fd669f73039529` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_bbf28cdf796b929b` → `chunk_08d67f9ea2f8c3bf`: file_import; symbol: not specified
- `chunk_bbf28cdf796b929b` → `chunk_6c67156ce7d4bcad`: imports_symbol; symbol: _default
- `chunk_bbf28cdf796b929b` → `chunk_6c67156ce7d4bcad`: file_import; symbol: not specified
- `chunk_bbf28cdf796b929b` → `chunk_a793714a798140b5`: file_import; symbol: not specified
- `chunk_bbf28cdf796b929b` → `chunk_d89edffad1fc2099`: imports_module; symbol: not specified
- `chunk_bbf28cdf796b929b` → `chunk_d89edffad1fc2099`: file_import; symbol: not specified
- `chunk_c0eef923d4b41e30` → `chunk_0c32d6cc911ef525`: imports_symbol; symbol: flash
- `chunk_c0eef923d4b41e30` → `chunk_2c910577b76376cf`: imports_symbol; symbol: render_template
- `chunk_c0eef923d4b41e30` → `chunk_5d5cf31f2ee2c92c`: imports_symbol; symbol: url_for
- `chunk_c0eef923d4b41e30` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_c0eef923d4b41e30` → `chunk_ccdfaa0f380ec07a`: imports_symbol; symbol: get_db
- `chunk_c0eef923d4b41e30` → `chunk_ccdfaa0f380ec07a`: file_import; symbol: not specified
- `chunk_c0eef923d4b41e30` → `chunk_fc92c568a3e5fcab`: imports_symbol; symbol: redirect
- `chunk_c4e9fd0132a01851` → `chunk_091ff3fea5244e71`: imports_symbol; symbol: FlaskClient
- `chunk_c4e9fd0132a01851` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_c4e9fd0132a01851` → `chunk_7e5fa90f1cd8ceed`: imports_symbol; symbol: Request
- `chunk_c4e9fd0132a01851` → `chunk_ae6ad21b2fc0258f`: file_import; symbol: not specified
- `chunk_c4e9fd0132a01851` → `chunk_e1d5287efc4fa5ef`: imports_symbol; symbol: Flask
- `chunk_c89a6b5182f3b837` → `chunk_08d67f9ea2f8c3bf`: file_import; symbol: not specified
- `chunk_c89a6b5182f3b837` → `chunk_d32aebe41ab61974`: file_import; symbol: not specified
- `chunk_c89a6b5182f3b837` → `chunk_d89edffad1fc2099`: imports_module; symbol: not specified
- `chunk_c89a6b5182f3b837` → `chunk_d89edffad1fc2099`: file_import; symbol: not specified
- `chunk_c8fa075adb35e66b` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_c8fa075adb35e66b` → `chunk_e1d5287efc4fa5ef`: imports_symbol; symbol: Flask
- `chunk_ccdfaa0f380ec07a` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_cd26e931d51d690c` → `chunk_08d67f9ea2f8c3bf`: file_import; symbol: not specified
- `chunk_cd26e931d51d690c` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_cd26e931d51d690c` → `chunk_e1d5287efc4fa5ef`: imports_symbol; symbol: Flask
- `chunk_ce6f30f5c7c658b8` → `chunk_08e16ed6f5967458`: file_import; symbol: not specified
- `chunk_ce6f30f5c7c658b8` → `chunk_091ff3fea5244e71`: imports_symbol; symbol: FlaskClient
- `chunk_ce6f30f5c7c658b8` → `chunk_277df63995874727`: imports_symbol; symbol: SessionInterface
- `chunk_ce6f30f5c7c658b8` → `chunk_3c8a6bfae0776ce3`: imports_symbol; symbol: SecureCookieSessionInterface
- `chunk_ce6f30f5c7c658b8` → `chunk_6f518c88b8a0e44d`: imports_module; symbol: not specified
- `chunk_ce6f30f5c7c658b8` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_ce6f30f5c7c658b8` → `chunk_ae6ad21b2fc0258f`: file_import; symbol: not specified
- `chunk_d18610b3e6441853` → `chunk_6f518c88b8a0e44d`: imports_module; symbol: not specified
- `chunk_d18610b3e6441853` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_d1c7038e934a6ce8` → `chunk_05e5b226d8a8f906`: file_import; symbol: not specified
- `chunk_d2edbd1432944397` → `chunk_08d67f9ea2f8c3bf`: file_import; symbol: not specified
- `chunk_d2edbd1432944397` → `chunk_08e16ed6f5967458`: file_import; symbol: not specified
- `chunk_d2edbd1432944397` → `chunk_344cc17acd65dd58`: imports_symbol; symbol: _CollectErrors
- `chunk_d2edbd1432944397` → `chunk_7f9d033f78e38483`: file_import; symbol: not specified
- `chunk_d2edbd1432944397` → `chunk_8cce5ef592c7abc6`: file_import; symbol: not specified
- `chunk_d2edbd1432944397` → `chunk_a793714a798140b5`: file_import; symbol: not specified
- `chunk_d2edbd1432944397` → `chunk_d89edffad1fc2099`: imports_module; symbol: not specified
- `chunk_d2edbd1432944397` → `chunk_d89edffad1fc2099`: file_import; symbol: not specified
- `chunk_d2edbd1432944397` → `chunk_ed378ed504c07fca`: file_import; symbol: not specified
- `chunk_d2edbd1432944397` → `chunk_fc344ad5edc4b52f`: file_import; symbol: not specified
- `chunk_d32aebe41ab61974` → `chunk_079d522beff21bdb`: imports_symbol; symbol: ConfigAttribute
- `chunk_d32aebe41ab61974` → `chunk_079d522beff21bdb`: file_import; symbol: not specified
- `chunk_d32aebe41ab61974` → `chunk_092f1c82779e9e8c`: imports_symbol; symbol: _AppCtxGlobals
- `chunk_d32aebe41ab61974` → `chunk_0f14a6cec0376f18`: imports_symbol; symbol: _endpoint_from_view_func
- `chunk_d32aebe41ab61974` → `chunk_2c910577b76376cf`: imports_symbol; symbol: DispatchingJinjaLoader
- `chunk_d32aebe41ab61974` → `chunk_2c910577b76376cf`: imports_symbol; symbol: Environment
- `chunk_d32aebe41ab61974` → `chunk_2c910577b76376cf`: file_import; symbol: not specified
- `chunk_d32aebe41ab61974` → `chunk_487841d24a31fccb`: file_import; symbol: not specified
- `chunk_d32aebe41ab61974` → `chunk_500c67581ba1971f`: imports_symbol; symbol: get_debug_flag
- `chunk_d32aebe41ab61974` → `chunk_5204c53d5d715ef6`: imports_symbol; symbol: _split_blueprint_path
- `chunk_d32aebe41ab61974` → `chunk_53f0d53d1eb1f300`: imports_symbol; symbol: setupmethod
- `chunk_d32aebe41ab61974` → `chunk_6c67156ce7d4bcad`: imports_symbol; symbol: DefaultJSONProvider
- `chunk_d32aebe41ab61974` → `chunk_6c67156ce7d4bcad`: imports_symbol; symbol: JSONProvider
- `chunk_d32aebe41ab61974` → `chunk_6c67156ce7d4bcad`: file_import; symbol: not specified
- `chunk_d32aebe41ab61974` → `chunk_8cce5ef592c7abc6`: file_import; symbol: not specified
- `chunk_d32aebe41ab61974` → `chunk_a793714a798140b5`: file_import; symbol: not specified
- `chunk_d32aebe41ab61974` → `chunk_ae6ad21b2fc0258f`: file_import; symbol: not specified
- `chunk_d32aebe41ab61974` → `chunk_c3d38c601dbe09fe`: imports_symbol; symbol: find_package
- `chunk_d32aebe41ab61974` → `chunk_c89a6b5182f3b837`: imports_module; symbol: not specified
- `chunk_d32aebe41ab61974` → `chunk_c89a6b5182f3b837`: imports_symbol; symbol: create_logger
- `chunk_d32aebe41ab61974` → `chunk_c89a6b5182f3b837`: file_import; symbol: not specified
- `chunk_d32aebe41ab61974` → `chunk_cd1ac4ab4dfc74dc`: imports_symbol; symbol: Config
- `chunk_d32aebe41ab61974` → `chunk_d2edbd1432944397`: file_import; symbol: not specified
- `chunk_d32aebe41ab61974` → `chunk_d633e0c444ff7754`: imports_symbol; symbol: Scaffold
- `chunk_d32aebe41ab61974` → `chunk_d89edffad1fc2099`: imports_module; symbol: not specified
- `chunk_d32aebe41ab61974` → `chunk_d89edffad1fc2099`: file_import; symbol: not specified
- `chunk_d32aebe41ab61974` → `chunk_e65b72105426b434`: file_import; symbol: not specified
- `chunk_d506393e345117c1` → `chunk_03327f5e7eb41467`: file_import; symbol: not specified
- `chunk_d506393e345117c1` → `chunk_08d67f9ea2f8c3bf`: file_import; symbol: not specified
- `chunk_d506393e345117c1` → `chunk_5d949a360d45c2ce`: imports_symbol; symbol: ScriptInfo
- `chunk_d506393e345117c1` → `chunk_6f518c88b8a0e44d`: imports_module; symbol: not specified
- `chunk_d506393e345117c1` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_d506393e345117c1` → `chunk_ae6ad21b2fc0258f`: file_import; symbol: not specified
- `chunk_d506393e345117c1` → `chunk_bbf28cdf796b929b`: imports_symbol; symbol: jsonify
- `chunk_d506393e345117c1` → `chunk_cbe68cbbc2b5ba76`: imports_symbol; symbol: EnvironBuilder
- `chunk_d506393e345117c1` → `chunk_ec73eaa6979995d4`: imports_symbol; symbol: FlaskCliRunner
- `chunk_d789d814bbcd589a` → `chunk_6f518c88b8a0e44d`: imports_module; symbol: not specified
- `chunk_d789d814bbcd589a` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_d89edffad1fc2099` → `chunk_ed378ed504c07fca`: file_import; symbol: not specified
- `chunk_d8ab3930496c9ba9` → `chunk_08d67f9ea2f8c3bf`: file_import; symbol: not specified
- `chunk_d8ab3930496c9ba9` → `chunk_08e16ed6f5967458`: file_import; symbol: not specified
- `chunk_d8ab3930496c9ba9` → `chunk_277df63995874727`: imports_symbol; symbol: SessionInterface
- `chunk_d8ab3930496c9ba9` → `chunk_6f518c88b8a0e44d`: imports_module; symbol: not specified
- `chunk_d8ab3930496c9ba9` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_d8ab3930496c9ba9` → `chunk_cd26e931d51d690c`: imports_symbol; symbol: app_ctx
- `chunk_ded3aeb584246617` → `chunk_08d67f9ea2f8c3bf`: file_import; symbol: not specified
- `chunk_ded3aeb584246617` → `chunk_091ff3fea5244e71`: imports_symbol; symbol: FlaskClient
- `chunk_ded3aeb584246617` → `chunk_6f518c88b8a0e44d`: imports_module; symbol: not specified
- `chunk_ded3aeb584246617` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_ded3aeb584246617` → `chunk_ae6ad21b2fc0258f`: file_import; symbol: not specified
- `chunk_ded3aeb584246617` → `chunk_cd26e931d51d690c`: imports_symbol; symbol: app_ctx
- `chunk_e0246e234c1bc17a` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_e0246e234c1bc17a` → `chunk_ccdfaa0f380ec07a`: imports_symbol; symbol: get_db
- `chunk_e0246e234c1bc17a` → `chunk_ccdfaa0f380ec07a`: file_import; symbol: not specified
- `chunk_e58c6f98322254c7` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_e58c6f98322254c7` → `chunk_e1d5287efc4fa5ef`: imports_symbol; symbol: Flask
- `chunk_e65b72105426b434` → `chunk_2c910577b76376cf`: imports_symbol; symbol: _default_template_ctx_processor
- `chunk_e65b72105426b434` → `chunk_2c910577b76376cf`: file_import; symbol: not specified
- `chunk_e65b72105426b434` → `chunk_5e3caeea08dd525b`: imports_symbol; symbol: get_root_path
- `chunk_e65b72105426b434` → `chunk_8cce5ef592c7abc6`: file_import; symbol: not specified
- `chunk_e65b72105426b434` → `chunk_d89edffad1fc2099`: imports_module; symbol: not specified
- `chunk_e65b72105426b434` → `chunk_d89edffad1fc2099`: file_import; symbol: not specified
- `chunk_e7009beab0a740e6` → `chunk_2c910577b76376cf`: imports_symbol; symbol: stream_template
- `chunk_e7009beab0a740e6` → `chunk_2c910577b76376cf`: imports_symbol; symbol: render_template
- `chunk_e7009beab0a740e6` → `chunk_2c910577b76376cf`: file_import; symbol: not specified
- `chunk_e7009beab0a740e6` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_e7009beab0a740e6` → `chunk_a793714a798140b5`: file_import; symbol: not specified
- `chunk_e7009beab0a740e6` → `chunk_bbf28cdf796b929b`: imports_symbol; symbol: jsonify
- `chunk_e7009beab0a740e6` → `chunk_d89edffad1fc2099`: imports_module; symbol: not specified
- `chunk_e7009beab0a740e6` → `chunk_d89edffad1fc2099`: file_import; symbol: not specified
- `chunk_e7009beab0a740e6` → `chunk_e1d5287efc4fa5ef`: imports_symbol; symbol: Flask
- `chunk_e7009beab0a740e6` → `chunk_e67d0957cb67fc02`: imports_symbol; symbol: Response
- `chunk_e7009beab0a740e6` → `chunk_ec18eff741183616`: imports_symbol; symbol: View
- `chunk_ec18eff741183616` → `chunk_08d67f9ea2f8c3bf`: file_import; symbol: not specified
- `chunk_ec18eff741183616` → `chunk_d89edffad1fc2099`: imports_module; symbol: not specified
- `chunk_ec18eff741183616` → `chunk_d89edffad1fc2099`: file_import; symbol: not specified
- `chunk_ed378ed504c07fca` → `chunk_340cdfcae1cb4b4d`: file_import; symbol: not specified
- `chunk_f5aec26423e2bf2b` → `chunk_6f518c88b8a0e44d`: imports_module; symbol: not specified
- `chunk_f5aec26423e2bf2b` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_f7d65a3c6b4deb6d` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_fb2dac7ac0d17108` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_fb2dac7ac0d17108` → `chunk_e1d5287efc4fa5ef`: imports_symbol; symbol: Flask
- `chunk_fb2dac7ac0d17108` → `chunk_e67d0957cb67fc02`: imports_symbol; symbol: Response
- `chunk_fc344ad5edc4b52f` → `chunk_03327f5e7eb41467`: file_import; symbol: not specified
- `chunk_fc344ad5edc4b52f` → `chunk_08d67f9ea2f8c3bf`: file_import; symbol: not specified
- `chunk_fc344ad5edc4b52f` → `chunk_08e16ed6f5967458`: file_import; symbol: not specified
- `chunk_fc344ad5edc4b52f` → `chunk_0974fadcf02fc3bc`: imports_symbol; symbol: get_load_dotenv
- `chunk_fc344ad5edc4b52f` → `chunk_14eaa200de800fcc`: imports_symbol; symbol: send_from_directory
- `chunk_fc344ad5edc4b52f` → `chunk_277df63995874727`: imports_symbol; symbol: SessionInterface
- `chunk_fc344ad5edc4b52f` → `chunk_2c910577b76376cf`: imports_symbol; symbol: Environment
- `chunk_fc344ad5edc4b52f` → `chunk_2c910577b76376cf`: file_import; symbol: not specified
- `chunk_fc344ad5edc4b52f` → `chunk_344cc17acd65dd58`: imports_symbol; symbol: _CollectErrors
- `chunk_fc344ad5edc4b52f` → `chunk_36957f18a0a76b79`: imports_symbol; symbol: get_flashed_messages
- `chunk_fc344ad5edc4b52f` → `chunk_3c8a6bfae0776ce3`: imports_symbol; symbol: SecureCookieSessionInterface
- `chunk_fc344ad5edc4b52f` → `chunk_500c67581ba1971f`: imports_symbol; symbol: get_debug_flag
- `chunk_fc344ad5edc4b52f` → `chunk_7e5fa90f1cd8ceed`: imports_symbol; symbol: Request
- `chunk_fc344ad5edc4b52f` → `chunk_7f9d033f78e38483`: file_import; symbol: not specified
- `chunk_fc344ad5edc4b52f` → `chunk_8cce5ef592c7abc6`: file_import; symbol: not specified
- `chunk_fc344ad5edc4b52f` → `chunk_a6940afbd6f42ea7`: imports_symbol; symbol: AppContext
- `chunk_fc344ad5edc4b52f` → `chunk_a793714a798140b5`: file_import; symbol: not specified
- `chunk_fc344ad5edc4b52f` → `chunk_ae6ad21b2fc0258f`: file_import; symbol: not specified
- `chunk_fc344ad5edc4b52f` → `chunk_cd26e931d51d690c`: imports_symbol; symbol: app_ctx
- `chunk_fc344ad5edc4b52f` → `chunk_d2edbd1432944397`: file_import; symbol: not specified
- `chunk_fc344ad5edc4b52f` → `chunk_d32aebe41ab61974`: file_import; symbol: not specified
- `chunk_fc344ad5edc4b52f` → `chunk_d89edffad1fc2099`: imports_module; symbol: not specified
- `chunk_fc344ad5edc4b52f` → `chunk_d89edffad1fc2099`: file_import; symbol: not specified
- `chunk_fc344ad5edc4b52f` → `chunk_dd100daace83e5ce`: imports_symbol; symbol: App
- `chunk_fc344ad5edc4b52f` → `chunk_e67d0957cb67fc02`: imports_symbol; symbol: Response
- `chunk_fc344ad5edc4b52f` → `chunk_ed378ed504c07fca`: file_import; symbol: not specified
- `chunk_fc5a015e48f7d783` → `chunk_2c910577b76376cf`: imports_symbol; symbol: render_template
- `chunk_fc5a015e48f7d783` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_fc5a015e48f7d783` → `chunk_8b04179a9854c150`: file_import; symbol: not specified
- `chunk_fc5a015e48f7d783` → `chunk_e1d5287efc4fa5ef`: imports_symbol; symbol: Flask
- `chunk_fcf9f39569fef058` → `chunk_2c910577b76376cf`: imports_symbol; symbol: render_template
- `chunk_fcf9f39569fef058` → `chunk_6f518c88b8a0e44d`: file_import; symbol: not specified
- `chunk_fcf9f39569fef058` → `chunk_bbf28cdf796b929b`: imports_symbol; symbol: jsonify

Other source sections remain available in `chunks.jsonl`; code is stored only once.

## 3. Business risks

Analysis status: **NO_REPORTABLE_FINDINGS**

No reportable risk findings. This does not mean the repository is risk-free.
