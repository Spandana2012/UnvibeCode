# Explore flask with AI

UnvibeCode connects your repository's business workflows, code relationships, and reported business risks to source code. You do not need to understand JSON to get started.

## 1. Get started

1. Download and extract `flask-repository-context.zip`.
2. Attach **both** `workflow_context.md` and `chunks.jsonl` to the same conversation in ChatGPT, Claude, or another AI assistant.
3. Choose a question below or write your own.

**Copying a question does not attach the source files.** Attach both files before sending your question.

## 2. Ask your AI

**Understand workflows**
> Using the attached `workflow_context.md` and `chunks.jsonl`, explain the main business workflows and show the functions that implement them. Cite source filenames and line numbers.

**Plan a code change**
> Using the attached files, help me assess how a proposed code change could affect workflows, functions, dependencies, and tests. First ask me what I plan to change.

**Explore business risks**
> Using the attached files, explain the reported business risks and their supporting source code. Distinguish validated findings from possible risks and missing evidence.

Keep the same AI conversation for follow-up questions.

## 3. What is included?

- **`workflow_context.md`** — Business workflows, connected code areas, source-code references, and reported risks.
- **`chunks.jsonl`** — The actual source code, stored once per section and identified by reference IDs.

### What is inside these two context files?

`workflow_context.md` explains validated workflows, other connected repository areas, and business risks. It provides source-code references and verified connections.

`chunks.jsonl` holds the source code itself, once per section. Your assistant can use the referenced IDs to find the relevant implementation.

When a relationship or risk is not verified, the assistant should say so rather than assume the analysis is complete.

### Why do I need to attach BOTH files?

The Markdown explains what the code does, while the JSONL provides the supporting source code. Copying a question cannot attach files to an external AI chat.

If your AI assistant does not accept ZIP files, extract the ZIP and upload both files individually.

[UnvibeCode](https://github.com/FinanceFlash/unvibecode)
